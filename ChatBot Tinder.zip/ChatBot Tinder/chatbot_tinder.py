import sys
import logging
import random
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import WebDriverException, NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
import openai
import os

# Intégrer l'API GPT-4 (OpenAI)
openai.api_key = os.getenv("OPENAI_API_KEY")

def get_gpt4_response(message, user_name):
    try:
        prompt = f"Un utilisateur Tinder nommé {user_name} t'a envoyé le message suivant: {message}. Réponds-lui naturellement et essaie de l'inviter à continuer la conversation sur Instagram si approprié."
        
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Tu es un chatbot qui répond sur Tinder. Tu dois parler Espagnol. Tu es une femme de 26 ans nommée Sheyla, qui est en séjour sur Madrid pendant 2 semaines, pour les vacances. Après invite lui un passé, comme tu veux, et une vie comme tu veux. Juste tu dois ramener petit à petit la conversation vers Instagram."},
                {"role": "user", "content": prompt}
            ]
        )
        gpt_response = response['choices'][0]['message']['content']
        return gpt_response
    except Exception as e:
        logging.error(f"Erreur lors de l'appel à GPT-4 : {e}")
        return "Désolé, je n'ai pas pu répondre pour l'instant."


# Chemin vers le fichier texte qui stocke les prénoms des utilisateurs déjà contactés
RESPONDED_USERS_FILE = "responded_users.txt"

# Fonction pour charger les utilisateurs contactés depuis un fichier
def load_responded_users():
    if os.path.exists(RESPONDED_USERS_FILE):
        with open(RESPONDED_USERS_FILE, "r") as file:
            return set(line.strip() for line in file)  # Charger les utilisateurs dans un set
    return set()

# Fonction pour sauvegarder les utilisateurs contactés dans un fichier
def save_responded_user(user_name):
    with open(RESPONDED_USERS_FILE, "a") as file:  # Ouvrir le fichier en mode ajout
        file.write(f"{user_name}\n")

# Charger la liste des utilisateurs auxquels on a déjà répondu
responded_users = load_responded_users()

# Vérifier si le répertoire existe, sinon le créer
log_directory = os.path.dirname('tinder_chatbot_logs.log')
if not os.path.exists(log_directory) and log_directory != '':
    os.makedirs(log_directory)

# Configurer le logger pour enregistrer les logs dans un fichier
logging.basicConfig(filename='tinder_chatbot_logs.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--remote-debugging-port=9222")

# Utiliser le chemin vers User Data et spécifier le profil exact
chrome_options.add_argument("user-data-dir=C:\\Users\\monar\\AppData\\Local\\Google\\Chrome\\User Data")
chrome_options.add_argument("profile-directory=Profile 2")  # Spécifier le dossier du profil

# Initialiser le WebDriver avec ChromeDriverManager pour télécharger ChromeDriver automatiquement
try:
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    logging.info("Chrome lancé avec succès avec le profil Profile 2.")
except Exception as e:
    logging.error(f"Erreur lors du lancement de Chrome: {e}")
    sys.exit(1)

# Attendre que tu actives manuellement ton VPN et te connectes à Tinder
logging.info("En attente de la connexion à Tinder et de l'activation du VPN...")
print("Veuillez vous connecter à Tinder et activer votre VPN. Appuyez sur Entrée une fois que c'est fait.")
input("Appuyez sur Entrée lorsque vous êtes prêt...")

# Accéder à la page de messages Tinder une fois connecté
try:
    driver.get("https://tinder.com/app/recs")
    logging.info("Accès à la page de messages Tinder réussi.")
    time.sleep(5)  # Attendre que la page se charge

    # Chercher et cliquer sur le bouton "Messages"
    try:
        messages_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Messages")]'))
        )
        messages_button.click()
        logging.info("Bouton 'Messages' cliqué.")
    except TimeoutException:
        logging.info("Le bouton 'Messages' n'était pas présent.")
    time.sleep(5)  # Attendre un peu après avoir cliqué

except WebDriverException as e:
    logging.error(f"Erreur lors de l'accès à la page de messages Tinder: {e}")
    driver.quit()
    sys.exit(1)

# Fonction pour envoyer un message en utilisant GPT-4
def send_message(match, user_name, message_text):
    try:
        match.click()  # Sélectionner le match
        logging.info(f"Match sélectionné pour {user_name}.")
        time.sleep(random.uniform(1, 3))  # Pause aléatoire pour simuler un comportement humain

        # Utiliser GPT-4 pour générer une réponse
        response_message = get_gpt4_response(message_text, user_name)

        # Simuler la frappe et envoyer la réponse
        message_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//textarea[@placeholder="Rédigez un message"]'))
        )
        simulate_typing(response_message)
        message_box.clear()
        message_box.send_keys(response_message)

        # Envoyer le message
        send_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//button//span[text()="Envoyer"]'))
        )
        send_button.click()

        logging.info(f"Message envoyé à {user_name} : {response_message}")

        # Sauvegarder l'utilisateur contacté
        save_responded_user(user_name)
        responded_users.add(user_name)

        # Retourner à la page des messages après envoi
        driver.get("https://tinder.com/app/recs")
        logging.info("Retour à la page des messages.")
        time.sleep(5)

        # Chercher et cliquer sur le bouton "Messages"
        try:
            messages_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Messages")]'))
            )
            messages_button.click()
            logging.info("Bouton 'Messages' cliqué.")
        except TimeoutException:
            logging.info("Le bouton 'Messages' n'était pas présent.")
        time.sleep(5)  # Attendre un peu après avoir cliqué

    except NoSuchElementException as e:
        logging.error(f"Erreur lors de l'envoi du message à {user_name} : {e}")
    except TimeoutException as e:
        logging.error(f"Le délai d'attente pour l'envoi du message à {user_name} a expiré : {e}")
    except Exception as e:
        logging.error(f"Erreur inattendue lors de l'envoi du message à {user_name} : {e}")

# Fonction pour simuler un délai de frappe avant d'envoyer un message
def simulate_typing(message):
    typing_time = random.uniform(2, 5)  # Simule un délai de frappe entre 2 et 5 secondes
    logging.info(f"Simulation de frappe pendant {typing_time:.2f} secondes avant d'envoyer le message.")
    time.sleep(typing_time)

# Fonction pour vérifier les nouveaux messages
def check_for_new_messages():
    try:
        # Localiser les matchs ayant un nouveau message
        new_messages = driver.find_elements(By.XPATH, '//a[contains(@class, "messageListItem--isNew")]')

        # Ajouter une vérification du nombre de messages trouvés
        num_messages = len(new_messages)
        logging.info(f"Nombre de messages détectés : {num_messages}")

        if num_messages > 0:
            logging.info(f"{num_messages} nouveau(x) message(s) trouvé(s).")

            for i, match in enumerate(new_messages):
                try:
                    # Tenter de récupérer à nouveau l'élément si nécessaire (pour éviter StaleElementReferenceException)
                    match = driver.find_elements(By.XPATH, '//a[contains(@class, "messageListItem--isNew")]')[i]

                    # Extraire le nom de l'utilisateur
                    user_name_element = match.find_element(By.XPATH, './/h3[contains(@class, "messageListItem__name")]')
                    user_name = user_name_element.text  # Extraire le texte

                    logging.info(f"Message de l'utilisateur : {user_name}")

                    if user_name not in responded_users:  # Si l'utilisateur n'a pas encore été contacté
                        logging.info(f"Nouvelle personne détectée, Nom : {user_name}")

                        # Lire le dernier message reçu
                        message_element = match.find_element(By.XPATH, './/div[contains(@class, "messageListItem__message")]')
                        message_text = message_element.text  # Texte du message

                        # Envoyer une réponse basée sur GPT-4
                        send_message(match, user_name, message_text)
                    else:
                        logging.info(f"Utilisateur déjà contacté, Nom : {user_name}")
                except NoSuchElementException as e:
                    logging.error(f"Erreur lors de l'extraction du nom de l'utilisateur : {e}")
                except StaleElementReferenceException:
                    logging.warning("L'élément est obsolète, tentative de le localiser à nouveau.")
                    continue  # Relocaliser l'élément si une erreur survient

        else:
            logging.info("Aucun nouveau message trouvé.")
            print("Aucun nouveau message détecté lors de cette vérification.")

    except NoSuchElementException as e:
        logging.error(f"Erreur lors de la vérification des messages : {e}")

# Boucle infinie pour vérifier les nouveaux messages
try:
    while True:
        logging.info("Vérification des nouveaux messages...")
        check_for_new_messages()

        # Vérifier toutes les 5 minutes pour voir s'il y a de nouveaux messages
        logging.info("Prochaine vérification dans 5 minutes.")
        time.sleep(300)  # Attendre 5 minutes avant de vérifier à nouveau
except KeyboardInterrupt:
    logging.info("Fermeture manuelle du script par l'utilisateur.")
    driver.quit()  # Fermer le navigateur proprement lorsque tu termines
    sys.exit(0)
